#include<stdio.h>
#include<malloc.h>

typedef struct
{
	int anFabricatie;
	char* marca;
	float consumeMediu;
} masina;

void citireVectorMasini(masina* vect, int nr)
{
	char buffer[30];
	for (int i = 0; i < nr; i++)
	{
		printf("An fabricatie: ");
		scanf("%d", &vect[i].anFabricatie);
		printf("Marca: ");
		scanf("%s", buffer);
		vect[i].marca = (char*)malloc((strlen(buffer) + 1) *
			sizeof(char));
		strcpy(vect[i].marca, buffer);
		printf("Consum mediu: ");
		scanf("%f", &vect[i].consumeMediu);
	}
}

void afisareVectorMasini(masina* vect, int nr)
{
	for (int i = 0; i < nr; i++)
		printf("\nAn fabricatie = %d, Marca = %s, Consum mediu = %5.2f",
			vect[i].anFabricatie, vect[i].marca, vect[i].consumeMediu);
}

void citireMatrice(float** mat, int nrLin)
{
	for (int i = 0; i < nrLin; i++)
	{
		printf("Cod produs: ");
		scanf("%f", &mat[i][0]);
		printf("Pret produs: ");
		scanf("%f", &mat[i][1]);
		printf("Cantitate produs: ");
		scanf("%f", &mat[i][2]);
	}
}

void afisareMatrice(float** mat, int nrLin)
{
	for (int i = 0; i < nrLin; i++)
		printf("\nCod = %5.2f, Pret = %5.2f, Cantitate = %5.2f",
			mat[i][0], mat[i][1], mat[i][2]);
}

void dezalocareMatrice(float** mat, int nrLin)
{
	for (int i = 0; i < nrLin; i++)
		free(mat[i]);
	free(mat);
}

void dezalocareVectorMasini(masina* vect, int nr)
{
	for (int i = 0; i < nr; i++)
		free(vect[i].marca);
	free(vect);
}

void main()
{
	/*int nrMasini;
	printf("Nr. masini: ");
	scanf("%d", &nrMasini);

	masina* vect = (masina*)malloc(nrMasini * sizeof(masina));
	citireVectorMasini(vect, nrMasini);
	afisareVectorMasini(vect, nrMasini);
	dezalocareVectorMasini(vect, nrMasini); */

	/*int nrProd;
	printf("Nr. produse: ");
	scanf("%d", &nrProd);
	float** mat = (float**)malloc(nrProd * sizeof(float*));
	for (int i = 0; i < nrProd; i++)
		mat[i] = (float*)malloc(3 * sizeof(float));
	citireMatrice(mat, nrProd);
	afisareMatrice(mat, nrProd);
	dezalocareMatrice(mat, nrProd);*/

	int nrMasini;
	FILE* f = fopen("fisier.txt", "r");
	fscanf(f, "%d", &nrMasini);
	masina* vect = (masina*)malloc(nrMasini * sizeof(masina));
	char buffer[30];
	for (int i = 0; i < nrMasini; i++)
	{
		fscanf(f, "%d", &vect[i].anFabricatie);
		fscanf(f, "%s", buffer);
		vect[i].marca = (char*)malloc((strlen(buffer) + 1) *
			sizeof(char));
		strcpy(vect[i].marca, buffer);
		fscanf(f,"%f", &vect[i].consumeMediu);
	}
	fclose(f);
	afisareVectorMasini(vect, nrMasini);
	dezalocareVectorMasini(vect, nrMasini);
}